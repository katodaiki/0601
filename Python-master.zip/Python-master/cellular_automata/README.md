# Cellular Automata

* https://en.wikipedia.org/wiki/Cellular_automaton
* https://mathworld.wolfram.com/ElementaryCellularAutomaton.html
